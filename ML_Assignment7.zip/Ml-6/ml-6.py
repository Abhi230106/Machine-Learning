import pandas as pd # type: ignore
import numpy as np # type: ignore
from math import log2
from sklearn.preprocessing import KBinsDiscretizer # type: ignore
from sklearn.tree import DecisionTreeClassifier, plot_tree # type: ignore
import matplotlib.pyplot as plt # type: ignore
from sklearn.model_selection import train_test_split # type: ignore
from sklearn import tree # type: ignore
from sklearn.preprocessing import StandardScaler # type: ignore

# Load dataset
df = pd.read_excel(r"C:\Users\91900\Desktop\Ml-6\10-Java_AST_in_.xlsx")

# A1: Calculate Entropy 
def calculate_entropy(column):
    values, counts = np.unique(column, return_counts=True)
    probabilities = counts / counts.sum()
    entropy = -np.sum(probabilities * np.log2(probabilities))
    return entropy

entropy_value = calculate_entropy(df['ast_0'])
print("A1 - Entropy (ast_0):", entropy_value)

# A2: Calculate Gini Index
def calculate_gini(column):
    values, counts = np.unique(column, return_counts=True)
    probabilities = counts / counts.sum()
    gini = 1 - np.sum(probabilities**2)
    return gini

gini_value = calculate_gini(df['ast_0'])
print("A2 - Gini Index (ast_0):", gini_value)

# A3: Information Gain
def information_gain(df, feature_col, target_col):
    total_entropy = calculate_entropy(df[target_col])
    
    values, counts = np.unique(df[feature_col], return_counts=True)
    weighted_entropy = 0
    for i in range(len(values)):
        subset = df[df[feature_col] == values[i]]
        prob = counts[i] / np.sum(counts)
        weighted_entropy += prob * calculate_entropy(subset[target_col])
    info_gain = total_entropy - weighted_entropy
    return info_gain

info_gain = information_gain(df, 'ast_0', 'Final_Marks')
print("A3 - Information Gain for ast_0:", info_gain)

# A4: Equal Width Binning 
def equal_width_binning(column, bins=4, labels=None):
    binned_data = pd.cut(column, bins=bins, labels=labels)
    return binned_data

df['ast_0_binned'] = equal_width_binning(df['ast_0'], bins=4)
print("A4 - Binning done: \n", df[['ast_0', 'ast_0_binned']].head())

# A5: Decision Tree Module
features = ['ast_0', 'ast_1']
target = 'Final_Marks'

X = df[features]
y = df[target]

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

dt_model = DecisionTreeClassifier(max_depth=6, random_state=42)
dt_model.fit(X_train, y_train)

# A6: Visualize Decision Tree 
plt.figure(figsize=(20, 10))
plot_tree(dt_model, feature_names=features, class_names=True, filled=True)
plt.title("Decision Tree")
plt.show()

# A7: Decision Boundary Visualization 
from matplotlib.colors import ListedColormap # type: ignore

x_min, x_max = X.iloc[:, 0].min() - 1, X.iloc[:, 0].max() + 1
y_min, y_max = X.iloc[:, 1].min() - 1, X.iloc[:, 1].max() + 1
xx, yy = np.meshgrid(np.linspace(x_min, x_max, 300),
                     np.linspace(y_min, y_max, 300))

Z = dt_model.predict(scaler.transform(np.c_[xx.ravel(), yy.ravel()]))
Z = Z.reshape(xx.shape)

plt.figure(figsize=(14, 8))
plt.contourf(xx, yy, Z, alpha=0.4, cmap=plt.cm.Set3)
plt.scatter(X.iloc[:, 0], X.iloc[:, 1], c=y, edgecolors='k', cmap='Set1')
plt.xlabel(features[0])
plt.ylabel(features[1])
plt.title("Decision Boundary")
plt.show()
