import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# Load dataset
file_path = r"D:\Documents\ML\ML_AS_8\10-Java_AST_in_.xlsx"
df = pd.read_excel(file_path, sheet_name="in")

# Extract features and target variable
X = df.iloc[:, :-2].values  # All columns except last two
y = df['Final_Marks'].values  # Target variable

# Normalize features
scaler = StandardScaler()
X = scaler.fit_transform(X)

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Perceptron training function
def perceptron_train(X, y, learning_rate=0.1, epochs=100):
    num_inputs = X.shape[1]
    weights = np.random.rand(num_inputs)
    bias = np.random.rand()
    errors = []
    
    for epoch in range(epochs):
        total_error = 0
        for i in range(len(X)):
            y_pred = 1 if np.dot(X[i], weights) + bias >= 0 else 0
            error = y[i] - y_pred
            weights += learning_rate * error * X[i]
            bias += learning_rate * error
            total_error += abs(error)
        
        errors.append(total_error)
        if total_error == 0:
            break
    
    return weights, bias, errors

# Train perceptron
weights, bias, errors = perceptron_train(X_train, y_train)
print(f"Perceptron Weights: {weights}, Bias: {bias}")

# Plot error reduction
plt.plot(errors)
plt.xlabel("Epochs")
plt.ylabel("Total Error")
plt.title("Perceptron Training Error Reduction")
plt.show()

# Train MLP classifier
mlp = MLPClassifier(hidden_layer_sizes=(64,), activation='relu', max_iter=500, solver='adam', random_state=42)
mlp.fit(X_train, y_train)
y_pred = mlp.predict(X_test)

# Accuracy
accuracy = accuracy_score(y_test, y_pred)
print(f"MLP Accuracy: {accuracy:.4f}")
